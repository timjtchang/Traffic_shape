[ Please begin by replacing this file with "k3-README.txt" from the spec. ]
